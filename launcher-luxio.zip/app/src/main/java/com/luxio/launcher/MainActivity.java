package com.luxio.launcher;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/** Launcher Luxio: satu layar WebView (assets/index.html) + jembatan ke sistem head unit. */
public class MainActivity extends Activity {
    static boolean doaPertama = true;           // doa saat launcher pertama jalan setelah HU menyala

    final Handler h = new Handler(Looper.getMainLooper());
    WebView web;
    boolean siap, tampilDiLayar, doaTunggu;
    long layarMati, waktuTunggu;

    SharedPreferences pref;
    LocationManager lm;
    Location akhir;
    float trip, laju;
    long fixTerakhir;

    MediaSessionManager msm;
    MediaController ctl;
    boolean izinMusik;
    String kunciSampul = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        pref = getSharedPreferences("luxio", MODE_PRIVATE);
        trip = pref.getFloat("trip", 0f);
        getWindow().setStatusBarColor(0xff0e0e10);
        getWindow().setNavigationBarColor(0xff0e0e10);

        web = new WebView(this);
        web.setBackgroundColor(0xff0e0e10);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);
        web.addJavascriptInterface(new Jembatan(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) {
                siap = true;
                kirimTema(); kirimGps(); kirimMedia(true);
                if (doaPertama) { doaPertama = false; tampilDoa(); }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                bukaUri(r.getUrl().toString()); return true;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");

        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_SCREEN_ON);
        registerReceiver(layarRx, f);
        IntentFilter p = new IntentFilter(Intent.ACTION_PACKAGE_ADDED);
        p.addAction(Intent.ACTION_PACKAGE_REMOVED);
        p.addAction(Intent.ACTION_PACKAGE_CHANGED);
        p.addDataScheme("package");
        registerReceiver(paketRx, p);

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) mulaiGps();
        else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        mulaiMedia();
        h.post(detak);
    }

    @Override protected void onResume() {
        super.onResume();
        tampilDiLayar = true;
        if (!izinMusik) mulaiMedia();
        kirimTema();
        if (doaTunggu) {
            doaTunggu = false;
            if (SystemClock.elapsedRealtime() - waktuTunggu < 5 * 60000) js("tampilDoa()");
        }
    }

    @Override protected void onPause() { super.onPause(); tampilDiLayar = false; }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (i != null && i.hasCategory(Intent.CATEGORY_HOME)) js("beranda()");
    }

    @SuppressWarnings("deprecation")
    @Override public void onBackPressed() { js("kembali()"); }      // launcher tidak boleh tertutup

    @Override public void onConfigurationChanged(Configuration c) { super.onConfigurationChanged(c); kirimTema(); }

    @Override public void onRequestPermissionsResult(int k, String[] izin, int[] hasil) {
        if (hasil.length > 0 && hasil[0] == PackageManager.PERMISSION_GRANTED) mulaiGps();
    }

    @Override protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        try { unregisterReceiver(layarRx); unregisterReceiver(paketRx); } catch (Exception e) { }
        if (lm != null) lm.removeUpdates(dengarGps);
        if (ctl != null) ctl.unregisterCallback(ctlCb);
        if (msm != null) msm.removeOnActiveSessionsChangedListener(sesiBerubah);
        web.destroy();
        super.onDestroy();
    }

    void js(final String perintah) {
        if (!siap) return;
        h.post(() -> web.evaluateJavascript("try{" + perintah + "}catch(e){}", null));
    }

    /* ===== doa: layar menyala lagi setelah mati >= 1 menit ===== */
    void tampilDoa() {
        if (tampilDiLayar && siap) js("tampilDoa()");
        else { doaTunggu = true; waktuTunggu = SystemClock.elapsedRealtime(); }
    }

    final BroadcastReceiver layarRx = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (Intent.ACTION_SCREEN_OFF.equals(i.getAction())) {
                layarMati = SystemClock.elapsedRealtime();
                js("hentikanDoa()");
            } else if (layarMati > 0 && SystemClock.elapsedRealtime() - layarMati >= 60000) {
                layarMati = 0;
                h.postDelayed(MainActivity.this::tampilDoa, 800);
            }
        }
    };

    final BroadcastReceiver paketRx = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { js("muatApp()"); }
    };

    /* ===== tema gelap/terang mengikuti sistem ===== */
    void kirimTema() {
        int m = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        js("temaSistem(" + (m == Configuration.UI_MODE_NIGHT_YES) + ")");
    }

    /* ===== GPS: kecepatan & trip ===== */
    void mulaiGps() {
        try {
            lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, dengarGps, Looper.getMainLooper());
        } catch (Exception e) { }
    }

    final LocationListener dengarGps = new LocationListener() {
        @Override public void onLocationChanged(Location l) {
            fixTerakhir = SystemClock.elapsedRealtime();
            laju = l.hasSpeed() ? l.getSpeed() * 3.6f : 0f;
            boolean akurat = !l.hasAccuracy() || l.getAccuracy() <= 30;
            if (akhir != null && akurat && laju >= 3) {
                float d = akhir.distanceTo(l);
                if (d < 2000) { trip += d / 1000f; pref.edit().putFloat("trip", trip).apply(); }
            }
            if (akurat) akhir = l;
            kirimGps();
        }
        @Override public void onStatusChanged(String p, int s, Bundle b) { }
        @Override public void onProviderEnabled(String p) { }
        @Override public void onProviderDisabled(String p) { }
    };

    void kirimGps() {
        boolean ada = fixTerakhir > 0 && SystemClock.elapsedRealtime() - fixTerakhir < 5000;
        js("gps(" + (ada ? laju : 0) + "," + trip + "," + ada + ")");
    }

    final Runnable detak = new Runnable() {
        @Override public void run() {
            kirimGps();
            if (ctl != null) kirimMedia(false);
            h.postDelayed(this, 1000);
        }
    };

    /* ===== musik: lagu yang sedang diputar (perlu izin akses notifikasi) ===== */
    final MediaSessionManager.OnActiveSessionsChangedListener sesiBerubah = this::pilihSesi;

    void mulaiMedia() {
        msm = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
        ComponentName cn = new ComponentName(this, PendengarMusik.class);
        try {
            List<MediaController> l = msm.getActiveSessions(cn);
            msm.addOnActiveSessionsChangedListener(sesiBerubah, cn);
            izinMusik = true;
            pilihSesi(l);
        } catch (SecurityException e) {
            izinMusik = false;
            kirimMedia(true);
        }
    }

    void pilihSesi(List<MediaController> l) {
        MediaController pilih = null;
        if (l != null) for (MediaController c : l) {
            PlaybackState st = c.getPlaybackState();
            if (st != null && st.getState() == PlaybackState.STATE_PLAYING) { pilih = c; break; }
            if (pilih == null) pilih = c;
        }
        if (ctl != null && (pilih == null || !ctl.getSessionToken().equals(pilih.getSessionToken()))) {
            ctl.unregisterCallback(ctlCb); ctl = null;
        }
        if (pilih != null && ctl == null) { ctl = pilih; ctl.registerCallback(ctlCb, h); }
        kirimMedia(true);
    }

    final MediaController.Callback ctlCb = new MediaController.Callback() {
        @Override public void onPlaybackStateChanged(PlaybackState s) {
            if (s != null && s.getState() != PlaybackState.STATE_PLAYING && msm != null && izinMusik) {
                try { pilihSesi(msm.getActiveSessions(new ComponentName(MainActivity.this, PendengarMusik.class))); return; } catch (SecurityException e) { }
            }
            kirimMedia(false);
        }
        @Override public void onMetadataChanged(MediaMetadata m) { kirimMedia(true); }
        @Override public void onSessionDestroyed() {
            if (ctl != null) ctl.unregisterCallback(ctlCb);
            ctl = null;
            mulaiMedia();
        }
    };

    static String teks(MediaMetadata m, String... kunci) {
        for (String k : kunci) { CharSequence t = m.getText(k); if (t != null && t.length() > 0) return t.toString(); }
        return "";
    }

    void kirimMedia(boolean sampul) {
        try {
            JSONObject o = new JSONObject();
            o.put("izin", izinMusik);
            MediaMetadata m = ctl == null ? null : ctl.getMetadata();
            o.put("ada", m != null);
            if (m != null) {
                PlaybackState st = ctl.getPlaybackState();
                boolean main = st != null && st.getState() == PlaybackState.STATE_PLAYING;
                long pos = st == null ? 0 : st.getPosition();
                if (main && st.getLastPositionUpdateTime() > 0)
                    pos += (long) ((SystemClock.elapsedRealtime() - st.getLastPositionUpdateTime()) * st.getPlaybackSpeed());
                o.put("judul", teks(m, MediaMetadata.METADATA_KEY_TITLE, MediaMetadata.METADATA_KEY_DISPLAY_TITLE));
                o.put("artis", teks(m, MediaMetadata.METADATA_KEY_ARTIST, MediaMetadata.METADATA_KEY_ALBUM_ARTIST, MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE, MediaMetadata.METADATA_KEY_ALBUM));
                o.put("durasi", Math.max(0, m.getLong(MediaMetadata.METADATA_KEY_DURATION) / 1000));
                o.put("posisi", Math.max(0, pos / 1000));
                o.put("main", main);
                o.put("app", labelApp(ctl.getPackageName()));
            }
            js("media(" + o + ")");
            if (sampul) kirimSampul(m);
        } catch (Exception e) { }
    }

    void kirimSampul(MediaMetadata m) {
        Bitmap art = null;
        if (m != null) {
            art = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
            if (art == null) art = m.getBitmap(MediaMetadata.METADATA_KEY_ART);
        }
        String kunci = art == null ? "" : art.getWidth() + "x" + art.getHeight() + ":" + art.getGenerationId() + teks(m, MediaMetadata.METADATA_KEY_TITLE);
        if (kunci.equals(kunciSampul)) return;
        kunciSampul = kunci;
        if (art == null) { js("sampulMedia('')"); return; }
        Bitmap kecil = Bitmap.createScaledBitmap(art, 260, 260 * art.getHeight() / Math.max(1, art.getWidth()), true);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        kecil.compress(Bitmap.CompressFormat.JPEG, 82, bo);
        js("sampulMedia('data:image/jpeg;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP) + "')");
    }

    String labelApp(String pkg) {
        try { PackageManager pm = getPackageManager(); return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString(); }
        catch (Exception e) { return ""; }
    }

    void bukaUri(String u) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch (Exception e) { h.post(() -> Toast.makeText(this, "Tidak bisa membuka tautan", Toast.LENGTH_SHORT).show()); }
    }

    static String ikon64(Drawable d) {
        int n = 112;
        Bitmap bm = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
        d.setBounds(0, 0, n, n);
        d.draw(new Canvas(bm));
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 100, bo);
        return "data:image/png;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
    }

    /** Fungsi yang bisa dipanggil dari index.html lewat window.Android */
    class Jembatan {
        @JavascriptInterface public String bukaApp(String json) {
            try {
                JSONArray a = new JSONArray(json);
                PackageManager pm = getPackageManager();
                for (int i = 0; i < a.length(); i++) {
                    String p = a.getString(i);
                    final Intent it = pm.getLaunchIntentForPackage(p);
                    if (it == null) continue;
                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                    h.post(() -> { try { startActivity(it); } catch (Exception e) { } });
                    return p;
                }
            } catch (Exception e) { }
            return "";
        }

        @JavascriptInterface public boolean punya(String pkg) {
            return getPackageManager().getLaunchIntentForPackage(pkg) != null;
        }

        @JavascriptInterface public boolean playStore(String pkg) {
            if (!punya("com.android.vending")) return false;
            bukaUri("market://details?id=" + pkg);
            return true;
        }

        @JavascriptInterface public void bukaUri(String u) { MainActivity.this.bukaUri(u); }

        @JavascriptInterface public String daftarApp() {
            JSONArray out = new JSONArray();
            try {
                PackageManager pm = getPackageManager();
                Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> l = new ArrayList<>(pm.queryIntentActivities(q, 0));
                Collections.sort(l, new ResolveInfo.DisplayNameComparator(pm));
                HashSet<String> sudah = new HashSet<>();
                for (ResolveInfo r : l) {
                    String p = r.activityInfo.packageName;
                    if (p.equals(getPackageName()) || !sudah.add(p)) continue;
                    JSONObject o = new JSONObject();
                    o.put("pkg", p);
                    o.put("label", r.loadLabel(pm).toString());
                    o.put("ikon", ikon64(r.loadIcon(pm)));
                    out.put(o);
                }
            } catch (Exception e) { }
            return out.toString();
        }

        @JavascriptInterface public void resetTrip() {
            h.post(() -> { trip = 0; akhir = null; pref.edit().putFloat("trip", 0f).apply(); kirimGps(); });
        }

        @JavascriptInterface public void izinMusik() {
            bukaIntent(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
        }

        @JavascriptInterface public void media(final String k) {
            h.post(() -> {
                if (ctl != null) {
                    MediaController.TransportControls t = ctl.getTransportControls();
                    PlaybackState st = ctl.getPlaybackState();
                    if ("lanjut".equals(k)) t.skipToNext();
                    else if ("mundur".equals(k)) t.skipToPrevious();
                    else if (st != null && st.getState() == PlaybackState.STATE_PLAYING) t.pause();
                    else t.play();
                } else {
                    int kode = "lanjut".equals(k) ? KeyEvent.KEYCODE_MEDIA_NEXT
                             : "mundur".equals(k) ? KeyEvent.KEYCODE_MEDIA_PREVIOUS : KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE;
                    AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
                    am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, kode));
                    am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, kode));
                }
            });
        }
    }

    void bukaIntent(final Intent i) {
        h.post(() -> { try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception e) { } });
    }
}
